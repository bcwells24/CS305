package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	} 

}

@RestController
class ServerController{
    
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
    	String data = "Hello World Check Sum!";
    	MessageDigest msg = MessageDigest.getInstance("SHA-256"); // Object creation with MessageDigest Library.
		byte[] hashB = msg.digest(data.getBytes()); // Hash value of data string.
		String checkSum = byteConversion(hashB); // Use checkSum and byteConversion method to generate hex string.
		return "<p>String Data: " + data + "<br> Cryptographic Hash Algorithm: " + msg + "<br>" + "CheckSum Value: " + checkSum + "</p>"; // Desired output.

    }
 
    
 // Method to convert byte array into hex string
    private String byteConversion(byte[] bytes) { // Convert byte array to hex with twice the length as each byte is two hex characters.
		StringBuilder hexStr = new StringBuilder(2 * bytes.length);
		for (byte x : bytes) { 
			String hex = Integer.toHexString(0xff & x); // Converting byte to hex.
			if (hex.length() == 1) {
				hexStr.append('0'); // Add 0 if needed to ensure 2 characters for each byte.
			}
			hexStr.append(hex); // Appending hex string.
		}
		return hexStr.toString(); // Return value, which is final hex representation.
	}
}
